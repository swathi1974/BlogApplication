import React, { useState } from 'react';
import { TextField, Grid, Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import Sidebar from './Sidebar'; 
import './Admin.css'; 

const Admin = () => {
  const [form, setForm] = useState({
    title: '',
    img: '',
    catg: '',
    description: '',
  });

  const navigate = useNavigate();

  let initialValue;
  if (localStorage.getItem('Blog') === null) {
    initialValue = [];
  } else {
    initialValue = JSON.parse(localStorage.getItem('Blog'));
  }

  const [value, setValue] = useState(initialValue);

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const newUserId = value.length === 0 ? 1 : value[value.length - 1].u_id + 1;

    const details = {
      u_id: newUserId,
      ...form,
    };

    const updatedValue = [...value, details];
    setValue(updatedValue);

    await localStorage.setItem('Blog', JSON.stringify(updatedValue));
  };

  return (
    <div className="admin-container">
      <h1>Admin Page</h1>
      <Grid container spacing={5}>
        <Grid item xs={24} sm={10}>
          <TextField
            label="Title"
            fullWidth
            name="title"
            onChange={(e) => {
              handleChange(e);
            }}
            InputLabelProps={{
              style: { color: 'white' },
            }}
          />
        </Grid> <br />
        <Grid item xs={12} sm={10}>
          <TextField
            label="Image"
            fullWidth
            name="img"
            onChange={(e) => {
              handleChange(e);
            }}
            InputLabelProps={{
              style: { color: 'white' },
            }}
          />
        </Grid> <br />
        <Grid item xs={12} sm={10}>
          <TextField
            label="Category"
            fullWidth
            name="catg"
            onChange={(e) => {
              handleChange(e);
            }}
            InputLabelProps={{
              style: { color: 'white' },
            }}
          />
        </Grid> <br />
        <Grid item xs={12} sm={10}>
          <TextField
            label="Description"
            fullWidth
            name="description"
            onChange={(e) => {
              handleChange(e);
            }}
            InputLabelProps={{
              style: { color: 'white' },
            }}
          />
        </Grid> <br />
        <Grid item xs={12}>
          <Button variant="contained" color="primary" onClick={handleSubmit}>
            Add Blog
          </Button>
        </Grid>
        {window.location.pathname.startsWith('/admin') && <Sidebar />}
      </Grid>
    </div>
  );
};

export default Admin;
