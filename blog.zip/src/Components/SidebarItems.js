const items=[
    
    {
        name:'View Blogs',
        path:'/viewblog'
},
]

export {items};