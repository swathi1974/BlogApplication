import React, { useEffect, useState } from 'react';
import ImgMediaCard from './ImgMediaCard';
import SearchBar from './SearchBar'; 
import TextField from '@mui/material/TextField'; 
import Autocomplete from '@mui/material/Autocomplete';
import './User.css';


const User = () => {
  const [data, setData] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');

  useEffect(() => {
    const storedData = JSON.parse(localStorage.getItem('Blog')) || [];
    setData(storedData);
  }, []);

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };


  return (
    <div>
      <h1>User Page</h1>
      <SearchBar searchTerm={searchTerm} onSearchChange={handleSearchChange} />

      <div className="card-container">
        <div className="category-dropdown">

        </div> <br />

        {data
          .filter(
            (Blog) =>
              Blog.title.toLowerCase().includes(searchTerm.toLowerCase()) &&
              (selectedCategory === '' || Blog.category === selectedCategory)
          )
          .map((Blog) => (
            <ImgMediaCard key={Blog.u_id} Blog={Blog} />
          ))}
      </div>
    </div>
  );
};

export default User;
